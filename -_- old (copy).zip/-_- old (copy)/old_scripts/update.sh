#!/bin/sh
pip3 install wget