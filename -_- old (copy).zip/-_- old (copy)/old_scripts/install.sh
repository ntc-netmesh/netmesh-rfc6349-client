#!/bin/sh
EVENT1=$USER
PWDPATH=$(pwd)
pkexec bash $PWDPATH/install2.sh $EVENT1 $PWDPATH
